#include "call.h"
#include "inode.h"
#include "superblock.h"
#include <string.h>
#include <stdlib.h>

#define DIR 1
const char *HD = "HD";

inode* read_inode(int fd, int i_number){
	inode* ip = malloc(sizeof(inode));
	int currpos=lseek(fd, INODE_OFFSET + i_number * sizeof(inode), SEEK_SET);
	if(currpos<0){
		printf("Error: lseek()\n");
		return NULL;
	}
	
	//read inode from disk
	int ret = read(fd, ip, sizeof(inode));
	if(ret != sizeof (inode) ){
		printf("Error: read()\n");
		return NULL;
	}
	return ip;
}

void print_dir_mappings(int fd, int i_number)
{
	inode* ip;
	ip = read_inode(fd, i_number);
	if(ip->i_type != DIR)
	{
		printf("Wrong path!\n");
		return;
	}

	DIR_NODE* p_block = (DIR_NODE* )malloc(BLOCK_SIZE);
	// Consider that SFS only supports at most 100 inodes so that only direct_blk[0] will be used,
	// the implementation is much easier
	int block_number = ip->direct_blk[0];
	int currpos=lseek(fd, DATA_OFFSET + block_number * BLOCK_SIZE, SEEK_SET);
	read(fd, p_block, BLOCK_SIZE);

	int file_idx = 0;
	printf("dir \t inode_number\n");
	for(file_idx = 0; file_idx < ip->file_num; file_idx++)
	{
		printf("%s \t %d\n", p_block[file_idx].dir, p_block[file_idx].inode_number);
	}
	free(p_block);
}

int match_dir_mappings(int fd, int i_number, char* buffer)
{
	inode* ip;
	ip = read_inode(fd, i_number);
	if(ip->i_type != DIR)
	{
		printf("Wrong path!\n");
		return -1;
	}

	DIR_NODE* p_block = (DIR_NODE* )malloc(BLOCK_SIZE);
	
	int block_number = ip->direct_blk[0];
	int currpos=lseek(fd, DATA_OFFSET + block_number * BLOCK_SIZE, SEEK_SET);
	read(fd, p_block, BLOCK_SIZE);

	int file_idx = 0;
	int ret =-1;

	for(file_idx = 0; file_idx < ip->file_num; file_idx++)
	{
		//printf("directory = %s\n", buffer);
		//printf("p_block.dir = %s\n", p_block[file_idx].dir);

		ret = strcmp(p_block[file_idx].dir, buffer);
		if(ret == 0)
		{
			return (p_block[file_idx].inode_number);
		}
	}

	free(p_block);
	printf("No match !\n");
	return -1;

}

void print_inode_info(inode* ip){
	printf("the inode information: \n");
	printf("i_number:	%d\n", ip->i_number);
	printf("i_mtime:	%s", ctime(& ip->i_mtime));
	printf("i_type:		%d\n", ip->i_type);
	printf("i_size:		%d\n", ip->i_size);
	printf("i_blocks:	%d\n", ip->i_blocks);
	printf("direct_blk[0]:	%d\n", ip->direct_blk[0]);
	printf("direct_blk[1]:	%d\n", ip->direct_blk[1]);
	printf("indirect_blk:	%d\n", ip->indirect_blk);
	printf("file_num:	%d\n", ip->file_num);
}

//split the directory and store in target array, count number of parts
int split(char* target[], char* pathname)
{
	int i=0;
	char *buffer = malloc(sizeof(char)*(strlen(pathname)));
    strcpy(buffer, pathname);

    if(buffer[0] != 47) //first not equal to "/", wrong and return
    {
        for(int j=0; j<100;j++)
        {
            target[j]= '\0';
        }
        printf("Directory Error\n");
        return -1;
    }
    
    char*p = strtok(buffer, "/");
    while (p != NULL)
    {
        target[i] = p;
        p = strtok (NULL, "/");
        i++;
    }
    
    if((buffer[1]=='\0'))
    {
        target[i] = ".";
        i++;
    }
    
    for(int j=i; j<100;j++)
    {
        target[j]= '\0';
    }

	return i;
}  //OK !

int open_t(char *pathname)
{
	int inode_number=0;

	char* buffer[100];
	int countDirectory;
	countDirectory = split(buffer, pathname);
	printf("%d\n", countDirectory);
	
	//open the HD
	int fd = open (HD, O_RDWR);
	if(fd == -1) //if failed
	{       
		printf("Error: open()\n");
		return -1;
	}

	//for each splited array
	for(int k=0; k<countDirectory; k++)
	{
		//print_dir_mappings(fd,inode_number);
		inode_number = match_dir_mappings(fd,inode_number,buffer[k]);
	}

	close(fd);
	return inode_number;
}  //OK !

int read_t(int inode_number, int offest, void *buf, int count)
{
	int read_bytes = 0;
	int fd = open (HD, O_RDWR);
	if(fd == -1) //if failed
	{       
		printf("Error: open()\n");
		return -1;
	}

	inode* ip = read_inode(fd, inode_number);
	//print_inode_info(ip);
	if(ip->i_type == 1)  //it is a directory
	{
		printf("This is a directory.\n");
		return -1;
	}

	int fileSize = ip->i_size;

	if( (offest +count ) >fileSize)
	{
		count = fileSize-offest;
	}

	int currentPosition;
	int overflowFlag = 0;
	int divide;
	int remainSize = count;

	int begin;
	int ending;
	int pos;

	int dirBLK0  = ip->direct_blk[0];
	int dirBLK1  = ip->direct_blk[1];
	int indirBLK = ip->indirect_blk;

	//find out offset: begins
	begin = (offest)/BLOCK_SIZE;
	//printf("begin = %d\n", begin);
	//find out count: ends
	ending = (offest + count - 1)/BLOCK_SIZE;
	//printf("ending = %d\n", ending);

	if(offest > fileSize)
	{
		read_bytes = 0;
		printf("Offset out of range!\n");
		return read_bytes;
	}else if(begin == 0) //1st direct block
	{
		//begin position
		currentPosition = DATA_OFFSET + dirBLK0 * BLOCK_SIZE + offest;
		pos = lseek(fd, currentPosition, SEEK_SET);
		if(ending == 0)
		{
			read_bytes = read(fd, buf, count);
			close(fd);
			return read_bytes;
		}
		else if(ending == 1) //end at 2nd direct blk
		{
			read_bytes = read(fd, buf, BLOCK_SIZE-offest);
			currentPosition = DATA_OFFSET + dirBLK1 * BLOCK_SIZE;
			pos = lseek(fd, currentPosition, SEEK_SET);
			read_bytes = read_bytes + read(fd,buf, count-(BLOCK_SIZE-offest));
			close(fd);
			return read_bytes;
		}
		else //end at indirect block
		{
			//check overflow
			read_bytes = read(fd, buf, BLOCK_SIZE-offest); //1st dirblk
			currentPosition = DATA_OFFSET + dirBLK1 * BLOCK_SIZE;
			pos = lseek(fd, currentPosition, SEEK_SET);
			read_bytes = read_bytes + read(fd,buf, BLOCK_SIZE); //2nd

			currentPosition = DATA_OFFSET + indirBLK * BLOCK_SIZE;
			pos = lseek(fd, currentPosition, SEEK_SET);

			remainSize = remainSize - BLOCK_SIZE -(BLOCK_SIZE-offest);
			if( (remainSize- (fileSize-2*BLOCK_SIZE))>0 ) //maximum
			{
				printf("Access the maximum number of blocks\n");
				read_bytes = read_bytes + read(fd,buf,fileSize-2*BLOCK_SIZE);
				close(fd);
				return read_bytes;
			}
			else
			{
				read_bytes = read_bytes + read(fd,buf, remainSize);
				close(fd);
				return read_bytes;
			}	
		}
	}
	else if(begin == 1) //2nd direct block
	{
		currentPosition=DATA_OFFSET+dirBLK1*BLOCK_SIZE+ offest -BLOCK_SIZE;
		pos = lseek(fd, currentPosition, SEEK_SET);
		if(ending == 1)
		{
			read_bytes = read(fd, buf, count);
			close(fd);
			return read_bytes;
		}else
		{
			read_bytes = read(fd, buf, 2*BLOCK_SIZE - offest); //2nd dirblk
			currentPosition = DATA_OFFSET + indirBLK * BLOCK_SIZE;

			remainSize = remainSize - (2*BLOCK_SIZE-offest);
			if((remainSize- (fileSize-2*BLOCK_SIZE))>0 ) //max
			{
				printf("Overflow\n");
				read_bytes = read_bytes + read(fd,buf, fileSize-2*BLOCK_SIZE);
				close(fd);
				return read_bytes;
			}
			else
			{
				read_bytes = read_bytes + read(fd,buf, remainSize);
				close(fd);
				return read_bytes;
			}
		}
	}
	else //begin at indirect block
	{
		currentPosition=DATA_OFFSET+indirBLK*BLOCK_SIZE+offest-2*BLOCK_SIZE;
		pos = lseek(fd, currentPosition, SEEK_SET);

		if( (count -(fileSize-offest)) >0 )
		{
			printf("Overflow!\n");
			read_bytes = read(fd,buf, fileSize-offest);
			close(fd);
			return read_bytes;
		}
		else
		{
			read_bytes = read_bytes + read(fd,buf, remainSize);
			close(fd);
			return read_bytes;
		}
	}
}

// you are allowed to create any auxiliary functions that can help your implementation. But only “open_t()” and "read_t()" are allowed to call these auxiliary functions.